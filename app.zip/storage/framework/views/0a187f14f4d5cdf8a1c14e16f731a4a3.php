<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('title', 'Administrar Propiedades'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="row">
    <div class="col-md-9">
        <h1>Administrar Propiedades de <?php echo e($sede->nombre); ?></h1>
    </div>
    <div class="text-right col-md-3">
        <a href="<?php echo e(route('propiedad.grupo.agregar',['id' => $sede->id])); ?>" class="btn btn-outline-primary btn-flat"><i class="fas fa-plus"></i> Crear Grupo de Propiedades</a>
    </div>
</div>
    
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('propiedad.tabla')); ?>">Propiedades</a></li>
            <li class="breadcrumb-item active" aria-current="page">Administrar Propiedades de <?php echo e($sede->nombre); ?></li>
        </ol>
    </nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-header">
            <div class="row">
                
                <div class="col-6"><?php if(isset($grupo->fk_tipo_gr_propiedad)): ?> <?php echo e($grupo->tipo_gr_propiedad->nombre); ?>: <?php endif; ?><?php echo e($grupo->nombre); ?></div>
                <div class="col-6 text-right">
                    <a href="<?php echo e(route('propiedad.grupo.item.agregar',['id' => $grupo->id])); ?>" class="btn btn-outline-secondary" type="button"><i class="fas fa-plus"></i> Nueva propiedad</a>
                    <a href="<?php echo e(route('propiedad.grupo.modificar',['id' => $grupo->id])); ?>" class="btn btn-outline-secondary"><i class="fas fa-pen"></i></a>
                    <a href="<?php echo e(route('propiedad.grupo.eliminar',['id' => $grupo->id])); ?>" class="btn btn-outline-danger preguntar" data-mensaje="Eliminar el grupo de propiedades"><i class="fas fa-trash"></i></a>
                </div>
            </div>
        </div>    
        <div class="card-body">
            <div class="row">
            <?php $__currentLoopData = $grupo->propiedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propiedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-2 col-lg-3 col-md-3 col-4">
                    <div class="sub-item"> 
                        <span><?php echo e($propiedad->nombre); ?></span>
                        <a href="<?php echo e(route('propiedad.grupo.item.modificar', ['id' => $propiedad->id])); ?>" class="btn btn-secondary"><i class="fas fa-pen"></i></a>
                        <a href="<?php echo e(route('propiedad.grupo.item.eliminar', ['id' => $propiedad->id])); ?>" class="btn btn-danger preguntar" data-mensaje="Eliminar la propiedad"><i class="fas fa-trash"></i></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\MDC\VigilanciaLaravel\vigilancia_laravel\resources\views/propiedad/config.blade.php ENDPATH**/ ?>