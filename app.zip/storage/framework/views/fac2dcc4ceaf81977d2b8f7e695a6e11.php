<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('title', 'Usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <div class="col-md-9">
            <h1>Usuarios</h1>
        </div>
        <div class="text-right col-md-3">
            <a href="<?php echo e(route('usuarios.agregar')); ?>" class="btn btn-outline-primary btn-flat"><i class="fas fa-plus"></i> Crear Usuario</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped datatable">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Propiedades</th>
                        <th>Email</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($usuario->name); ?></td>
                            <td><?php echo e($usuario->sedes_txt()); ?></td>
                            <td><?php echo e($usuario->email); ?></td>
                            <td class="text-right">
                                <a href="<?php echo e(route('usuarios.modificar',['id' => $usuario->id])); ?>" class="btn btn-secondary"><i class="fas fa-pen"></i> Modificar</a>
                                <a href="<?php echo e(route('usuarios.eliminar',['id' => $usuario->id])); ?>" class="btn btn-danger preguntar" data-mensaje="Eliminar el usuario"><i class="fas fa-trash"></i> Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\MDC\VigilanciaLaravel\vigilancia_laravel\resources\views/usuarios/tabla.blade.php ENDPATH**/ ?>