<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('title', 'Buzón'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Buzón</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped datatable">
                <thead>
                    <tr>
                        <th>Propiedad</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Residente</th>
                        <th>Estado del código</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $paquetes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paquete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($paquete->propiedad->gr_propiedad->sede->nombre); ?></td>
                            <td><?php echo e(date("Y/m/d", strtotime($paquete->fecha_recepcion))); ?></td>
                            <td><?php echo e(date("H:i", strtotime($paquete->fecha_recepcion))); ?></td>
                            <td><?php echo e($paquete->propiedad->propietario->nombres); ?> <?php echo e($paquete->propiedad->propietario->apellidos); ?> </td>
                            <td>
                                <?php if($paquete->entregado == "1"): ?>
                                    Entregado
                                <?php else: ?>
                                    <a href="<?php echo e(route('paquetes.validar',['id' => $paquete->id])); ?>" class="btn btn-outline-primary"><i class="fas fa-check"></i> Validar código</a>
                                <?php endif; ?>
                            </td>
                            <td class="text-right">
                                <a href="<?php echo e(route('paquetes.verDetalles',['id' => $paquete->id])); ?>" class="btn btn-outline-success ver_paquete"><i class="fas fa-eye"></i> Ver</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="modal fade" id="verPaqueteModal" tabindex="-1" aria-labelledby="verPaqueteModal" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Resumen</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="resumen_paquete"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).ready(function(e){
            $("body").on("click",".ver_paquete",function(e){
                e.preventDefault()
                $.ajax({
                    type: 'GET',
                    url: $(this).attr("href"),
                    success: function(data) {
                        if(data.success){
                            $("#verPaqueteModal").modal("show");
                            $(".resumen_paquete").html(data.html);
                        }                        
                    },
                    error: function(data) {
                        console.log("error");
                        console.log(data);
                    }
                });
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Trabajo\MDC\VigilanciaLaravel\vigilancia_laravel\resources\views/paquetes/tabla.blade.php ENDPATH**/ ?>