<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Minuta - <?php echo e($paquete->id); ?></title>
</head>
<body>
    <style>
        *{
            font-family: sans-serif;
        }
        @page{
            margin: 0;
            padding: 0;
        }
        .row{
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }
        .col-md-3{
            width: 24%;
            display: inline-block;
        }
        .imagen-cont{
            width: 90%;
        }
        .w-100{
            width: 100%;
        }
        .centrar{
            padding: 40px 40px;
        }
    </style>
    <div class="centrar">
        <h5>Datos recepción</h5>
        <div class="row">
            <div class="col-md-3 col-12">
                <b>Fecha</b><br>
                <span><?php echo e(date("Y/m/d", strtotime($paquete->fecha_recepcion))); ?></span>
            </div>
            <div class="col-md-3 col-12">
                <b>Hora</b><br>
                <span><?php echo e(date("H:i", strtotime($paquete->fecha_recepcion))); ?></span>
            </div>
            <div class="col-md-3 col-12">
                <b>Propiedad</b><br>
                <span><?php echo e($paquete->propiedad->nombre); ?></span>
            </div>
            <div class="col-md-3 col-12">
                <b>Recibe</b><br>
                <span><?php echo e($paquete->user_recibe->name); ?></span>
            </div>
        </div>
        <h5>Datos entrega</h5>
        <div class="row">
            <?php if(!isset($paquete->fecha_entrega) || $paquete->fecha_entrega == null): ?>
                <div class="col-md-12 col-12">
                    <b>Aun no se ha entregado</b><br>
                </div>
            <?php else: ?>
                <div class="col-md-3 col-12">
                    <b>Fecha</b><br>
                    <span><?php echo e(date("Y/m/d", strtotime($paquete->fecha_recepcion))); ?></span>
                </div>
                <div class="col-md-3 col-12">
                    <b>Hora</b><br>
                    <span><?php echo e(date("H:i", strtotime($paquete->fecha_recepcion))); ?></span>
                </div>
                <div class="col-md-3 col-12">
                    <b>Propietario</b><br>
                    <span><?php echo e($paquete->propiedad->propietario->nombres); ?> <?php echo e($paquete->propiedad->propietario->apellidos); ?></span>
                </div>
                <div class="col-md-3 col-12">
                    <b>Entrega</b><br>
                    <span><?php echo e($paquete->user_entrega->name); ?></span>
                </div>
            <?php endif; ?>
            <div class="col-12">
                <b>Observacion</b><br>
                <span><?php echo e($paquete->observacion); ?></span>
            </div>
            <div class="col-12">
                <b>Imagenes</b><br>
                    <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <figure class="imagen-cont">
                            <img src="data:image/png;base64,<?php echo e($foto->img_base64); ?>" class="w-100" />
                        </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php /**PATH D:\Trabajo\MDC\VigilanciaLaravel\vigilancia_laravel\resources\views/paquetes/pdf.blade.php ENDPATH**/ ?>