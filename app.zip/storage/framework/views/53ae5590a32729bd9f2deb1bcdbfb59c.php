<h5>Datos recepción</h5>
<div class="row">
    <div class="col-md-3 col-12">
        <b>Fecha</b><br>
        <span><?php echo e(date("Y/m/d", strtotime($paquete->fecha_recepcion))); ?></span>
    </div>
    <div class="col-md-3 col-12">
        <b>Hora</b><br>
        <span><?php echo e(date("H:i", strtotime($paquete->fecha_recepcion))); ?></span>
    </div>
    <div class="col-md-3 col-12">
        <b>Propiedad</b><br>
        <span><?php echo e($paquete->propiedad->nombre); ?></span>
    </div>
    <div class="col-md-3 col-12">
        <b>Recibe</b><br>
        <span><?php echo e($paquete->user_recibe->name); ?></span>
    </div>
</div>
<h5>Datos entrega</h5>
<div class="row">
    <?php if(!isset($paquete->fecha_entrega) || $paquete->fecha_entrega == null): ?>
        <div class="col-md-12 col-12">
            <b>Aun no se ha entregado</b><br>
        </div>
    <?php else: ?>
        <div class="col-md-3 col-12">
            <b>Fecha</b><br>
            <span><?php echo e(date("Y/m/d", strtotime($paquete->fecha_recepcion))); ?></span>
        </div>
        <div class="col-md-3 col-12">
            <b>Hora</b><br>
            <span><?php echo e(date("H:i", strtotime($paquete->fecha_recepcion))); ?></span>
        </div>
        <div class="col-md-3 col-12">
            <b>Propietario</b><br>
            <span><?php echo e($paquete->propiedad->propietario->nombres); ?> <?php echo e($paquete->propiedad->propietario->apellidos); ?></span>
        </div>
        <div class="col-md-3 col-12">
            <b>Entrega</b><br>
            <span><?php echo e($paquete->user_entrega->name); ?></span>
        </div>
    <?php endif; ?>
    <div class="col-12">
        <b>Observacion</b><br>
        <span><?php echo e($paquete->observacion); ?></span>
    </div>
    <div class="col-12">
        <b>Imagenes</b><br>
        <div class="row">
            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <figure class="col-md-4 col-12">
                    <img src="<?php echo e(Storage::url('paquetes/max_'.$foto->ruta)); ?>" class="w-100" />
                </figure>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-12 text-center">
        <a href="<?php echo e(route('paquetes.pdf',['id' => $paquete->id])); ?>" class="btn btn-outline-danger"><i class="fas fa-file-pdf"></i> Descargar PDF</a>
    </div>
</div>


<?php /**PATH D:\Trabajo\MDC\VigilanciaLaravel\vigilancia_laravel\resources\views/paquetes/detalle.blade.php ENDPATH**/ ?>