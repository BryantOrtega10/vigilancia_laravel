<div class="row">
    <div class="col-md-3 col-12">
        <b>Fecha</b><br>
        <span><?php echo e(date("Y/m/d", strtotime($minuta->fecha_reporte))); ?></span>
    </div>
    <div class="col-md-3 col-12">
        <b>Hora</b><br>
        <span><?php echo e(date("H:i", strtotime($minuta->fecha_reporte))); ?></span>
    </div>
    <div class="col-md-3 col-12">
        <b>Propiedad</b><br>
        <span><?php echo e($minuta->sede->nombre); ?></span>
    </div>
    <div class="col-md-3 col-12">
        <b>Responsable</b><br>
        <span><?php echo e($minuta->user->name); ?></span>
    </div>
    <div class="col-12">
        <b>Observacion</b><br>
        <span><?php echo e($minuta->observacion); ?></span>
    </div>
    <div class="col-12">
        <b>Imagenes</b><br>
        <div class="row">
            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <figure class="col-md-4 col-12">
                    <img src="<?php echo e(Storage::url('minutas/max_'.$foto->ruta)); ?>" class="w-100" />
                </figure>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-12 text-center">
        <a href="<?php echo e(route('minuta.pdf',['id' => $minuta->id])); ?>" class="btn btn-outline-danger"><i class="fas fa-file-pdf"></i> Descargar PDF</a>
    </div>
</div>


<?php /**PATH D:\Trabajo\MDC\VigilanciaLaravel\vigilancia_laravel\resources\views/minutas/detalle.blade.php ENDPATH**/ ?>